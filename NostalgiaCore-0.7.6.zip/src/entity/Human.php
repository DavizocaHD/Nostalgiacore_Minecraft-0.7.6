<?php

class Human extends Creature{
	const CLASS_TYPE = ENTITY_PLAYER;
}