<?php
abstract class Projectile extends Entity{
	const CLASS_TYPE = ENTITY_OBJECT;
	
	
}