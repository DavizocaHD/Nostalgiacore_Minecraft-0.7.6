<?php

interface Rideable{
	public function canRide($e);
}