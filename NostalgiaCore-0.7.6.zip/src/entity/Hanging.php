<?php
//Useless Class(or not so usless =D?)
abstract class Hanging extends Entity implements Attachable{
	const CLASS_TYPE = ENTITY_OBJECT;
}