<?php
/*
Illegal features
*/
interface Pathfindable{
	public function hasPath();
}