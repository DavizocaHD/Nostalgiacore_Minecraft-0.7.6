<?php

class FlatBiome extends Biome
{
}

