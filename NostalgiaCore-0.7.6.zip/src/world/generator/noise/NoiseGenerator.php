<?php

abstract class NoiseGenerator{
	
}