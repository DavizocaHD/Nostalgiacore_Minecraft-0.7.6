<?php

class FuelData{

	public static $duration = [
		COAL => 80,
		TRUNK => 15,
		WOODEN_PLANKS => 15,
		SAPLING => 5,
		WOODEN_AXE => 10,
		WOODEN_PICKAXE => 10,
		WOODEN_SWORD => 10,
		WOODEN_SHOVEL => 10,
		WOODEN_HOE => 10,
		STICK => 5,
		FENCE => 15,
		FENCE_GATE => 15,
		WOODEN_STAIRS => 15,
		TRAPDOOR => 15,
		WORKBENCH => 15,
		BOOKSHELF => 15,
		CHEST => 15,
		BUCKET => 1000,
	];

}