<?php

class SmeltingData{

	public static $product = [
		COBBLESTONE => [STONE, 0],
		SAND => [GLASS, 0],
		TRUNK => [COAL, 1], //Charcoal
		GOLD_ORE => [GOLD_INGOT, 0],
		IRON_ORE => [IRON_INGOT, 0],
		NETHERRACK => [NETHER_BRICK, 0],
		RAW_PORKCHOP => [COOKED_PORKCHOP, 0],
		CLAY => [BRICK, 0],
		CACTUS => [DYE, 2],
		RED_MUSHROOM => [DYE, 1],
		RAW_BEEF => [STEAK, 0],
		RAW_CHICKEN => [COOKED_CHICKEN, 0],
	];
}