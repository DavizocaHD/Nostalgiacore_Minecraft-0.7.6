<?php

class Packet extends stdClass{

	public $ip;
	public $port;
	public $buffer;

}